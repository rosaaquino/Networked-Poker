// Server side of Poker game. a**hole doesnt like me
var player = [];

let app = require('http').createServer(); // create HTTP server
let io = require('socket.io')(app, {path: '/socket.io'}); // bind Socket to HTTP server
app.listen(3000); // listen on port 3000
console.log('Listening for connections on port 3000');
var connectCounter = 0;
var inGame = 0;

//creates a person object that will be placed in an array
function person(clientNum, hand, score){
	this.clientNum = clientNum; // the number of tthe client in the connection array
	this.hand = hand; // an array that will hold the players hand
	this.score = score;// this keeps the persons score through out the game.
}

// creates the connection for the client 
io.on('connection', function(socket) {

   console.log('Socket connected');
   var allowPlayer = false;
   var newHand = dealCards();
   if(connectCounter < 4)
   {
 	  connectCounter = io.eio.clientsCount;
 	  allowPlayer = true;

	}
   socket.join('my-room');
   var obj = {allowPlayer:allowPlayer, counter:connectCounter, playerHand: newHand; };
   socket.in('my-room').emit('fromServer',obj);
   socket.on('fromClient', function(data){
   	inGame ++;
   	console.log('Received '+ data.id+ ' from client');
   });
   	socket.on('disconnect', function(){
    console.log('user disconnected '+ connectCounter);
   });


   	//dont know which one is working or if the work at all it should return the value i need

   	io.engine === io.eio // => true
var clients = Object.keys(io.engine.clients) // => [ 'US8AxrUrrDF_G7ZUAAAA', 'Ov2Ca24Olkhf2NHbAAAB' ]
var clients2 = Object.keys(io.eio.clients)    // => [ 'US8AxrUrrDF_G7ZUAAAA', 'Ov2Ca24Olkhf2NHbAAAB' ]
 });
function createPerson(){


}

function startGame()
{
	var obj = {id:"work"}
	socket.in('my-room').emit('fromServer',obj);
}

// creating the deck and using the deck must be handled by the server
/*
	var deck = [];
	var deckSize =52;
	var suits=[ "hearts", "diamonds", "clubs","spades"];
	var names= ["2","3","4","5","6","7","8","9","10","J","Q","K" ,"A"];
	
function serverStartGame(num)
{
	numberOfPlayers = num;
	CreateDeck();
	CreatePlayers();
	CreateHands();
	SendCardsToPlayers();
}



// create the deck of the game
function CreateDeck(){	
	var x = 0
	//forloops to create the deck
	for (var y = 0; y < suits.length; y++)
	{
		for(var z = 0; z < names.length; z++)
		{
			deck[x]= {value:names[z], suit:suits[y]};
			x++;
		}
	}	
}

//create the players
function serverCreatePlayers()
{
	for(var i = 0; i < numberOfPlayers; i ++)
	{
		players[i] = {cards:[], score:0, folded:false};
	}
}

//deal the cards to players
function serverCreateHands()
{
	if(deckSize > (numberOfPlayers * 5))
	{
		for(var i = 0; i < numberOfPlayers; i ++)
		{
			for(var c = 0; c < 5; c++)
			{
				players[i].cards[c] = serverDealCard();
			}
		}
	}
	else
	{
		alert("not enough cards for another round");
	}
}

//returns 1 card from the deck
function serverDealCard()
{	
	var deckIndex = randomInt();
	var card =  deck[deckIndex];
	//this will remove the card from the deck and rezise
	deck.splice(deckIndex,1);
	//decreases the size of the deck
	deckSize--;
	return card;
}

function randomInt(){

	return Math.floor(Math.random()* deckSize);
}

//returns the players obj to all users
function serverSendCardsToPlayers()
{
	getCardsAndDisplayThem(players);
}

//================================================================================

function serverRequestDraw(obj)
{
	for(var i = 0; i < obj.discart.length; i++)
	{
		players[obj.playerNum].cards[obj.discart[i]] = serverDealCard();
	}
	getCardsAndDisplayThem(players);
}

function serverRequestFold(obj)
{
	players[obj.playerNum].folded = true;
}

function serverRequestCompare()
{
	var s = "";
	s += '<table>'
	for(var i = 0; i < players.length; i++)
	{
		s += '<tr><td>Player '+i+'</td>';
		for(var c = 0; c < 5; c++)
		{
			s += '<td><img src="images/'+players[i].cards[c].value+players[i].cards[c].suit+'.png" style="cursor:pointer;margin:10px;height:100px;border-radius:4px;"/></td>'
		}
		s += '</tr>';
	}
	$("#cardDisplay").html(s);
}

*/


