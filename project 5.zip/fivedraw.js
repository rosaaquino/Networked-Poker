var player = null;
var deck = [];
var deckSize =52;
var suits=[ "hearts", "diamonds", "clubs","spades"];
var names= ["2","3","4","5","6","7","8","9","10","J","Q","K" ,"A"];
var hand = [];
var score = 0;
var myHand =[];
function startSocket(){
  		 var socket = io('http://localhost:3000', {path: '/socket.io'}); // connect to server
  		 socket.on('fromServer', function(answer) { // listen for fromServer message
	  		if (player == null)
	  		{
	  			if(answer.allowPlayer == false)
	  			{console.log(false)
	  				alert("Max player in room");
	  				window.open("https://www.youtube.com/watch?v=bESGLojNYSo", "_self");
	  			}
	  			player = answer.counter;
	  			myHand = answer.playerHand;
	  		}
	  		 console.log( answer);
	  		
	     socket.emit('fromClient', {id: 'bar'}); // send fromClient message to server

	     $("#score").html(score);
	     
	 });}


$(document).ready(function()
{
	createDeck();
	$("#deal").click(function(){
		dealCards(;
	});
});

$(document).ready(function(){
	$("#check").click(function(){
		checkHand(myHand);
	});
});
$(document).ready(function(){
	$("#draw").click(function(){
		drawCards();
	});
});

$(document).ready(function(){
	$("fold").click(function(){
		var A = []
		myHand = A;
	});
});

function createDeck(){	
	var x = 0
	//forloops to create the deck
	for (var y = 0; y < suits.length; y++)
	{
		for(var z = 0; z < names.length; z++)
		{
			deck[x]= names[z]+suits[y];
			//console.log(deck[x]);
			x++;
		}
	}	
}
function dealCards(){
	var handSize = hand.length;
	while (handSize < 5 )
	{
		var i = randomInt();
		if((deckSize == 0)||(handSize == 5))
			{
				console.log('No more cards delt');
				return false;
			}

		var image = document.createElement("img");
		image.src = deck[i]+".png";
		//this stores the cards in hand
		document.body.appendChild(image);
		hand = deck[i];
		//this will remove the card from the deck and rezise
		deck.splice(i,1);
		//decreases the size of the deck
		deckSize--;
		handSize ++;
	}
}

function drawCards(i){
	
	var handSize = hand.length;
	while (handSize < 5){

	if((deckSize == 0)||(handSize == 5))
		{
			console.log('No more cards delt');
			return false;
		}

	var image = document.createElement("img");
	image.src = deck[i]+".png";
	//this stores the cards in hand
	document.body.appendChild(image);
	hand = deck[i];
	//this will remove the card from the deck and rezise
	deck.splice(i,1);
	//decreases the size of the deck
	deckSize--;
	handSize++;
	}	
}	
function randomInt(){

	return Math.floor(Math.random()* deckSize);
}

function removeCard(dropped)
{

}


function checkHand(currentHand){




}






/*
function startNewGame(){
	deck();
	deal();

	$("#mainDisplay").html("");
}

function card(value, name, suit){
	this.value = value;
	this.name = name;
	this.suit = suit;
	//possibly add an image
}
//this builds the deck of cards and inputs the values for the cards
function deck(){
	this.names = [ '2', '3','4','5','7','8','9','10'
					'J','Q','K','A'];
	//dunno if i'll do the actual values
	this.values = ['2', '3','4','5','7','8','9','10'
					'11','12','13','14'];
	this.suits = ['clubs','hearts','diamonds','spades'];
	//this will iterate to create each suit
	for (var x = 0; x < this.suits.length; x++)
	{
		//this will create cards for the individual suit
		//they will be pushed into the array cards
		for(var y = 0; y< this.names.length; y++)
		{
			cards.push( new card( y+1, this.names[y], this.suits[x] ) );
		}
	} 
	for (var i = 0; i< 52; i++)
	{
		var temp = RandomInt();
		shuffled.push[i] = cards[temp];
	}
}


*/